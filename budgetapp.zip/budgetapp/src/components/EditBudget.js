import React, { useState } from 'react'

const EditBudget = (props) => {
    const [value, setValue] = useState(props.budget);

    return( 
        <div>

           <input required='required' type='number' class='form-control mr-3'
            id='name' value={value} onChange={(event)=> setValue(event.target.value)}/>

            <button type='button' class='btn btn-primary' onClick={() => props.handleSaveClick(value)}>save</button>

        </div>
    )
}

export default EditBudget